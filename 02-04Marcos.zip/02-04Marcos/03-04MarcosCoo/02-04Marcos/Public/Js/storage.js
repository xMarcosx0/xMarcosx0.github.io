// storage.js - Manejo de almacenamiento local para la aplicación

const Storage = {
  // Claves para localStorage
  KEYS: {
    USERS: "air_e_users",
    LOGGED_USER: "air_e_logged_user",
    PROJECTS: "air_e_projects",
    NOTIFICATIONS: "air_e_notifications",
    CENSUS: "air_e_census",
    COUNTER: "air_e_counter",
  },

  // Inicializar el almacenamiento
  init: function () {
    // Limpiar localStorage para asegurar que se creen los usuarios correctamente
    // (Solo para desarrollo, quitar en producción)
    // localStorage.clear()

    // Verificar si ya existen datos
    if (!localStorage.getItem(this.KEYS.USERS)) {
      // Crear usuarios por defecto
      const defaultUsers = [
        {
          id: "1",
          nombre: "Admin",
          apellido: "Sistema",
          correo: "admin@aire.com",
          password: "admin123",
          rol: "admin",
          activo: true,
        },
        {
          id: "2",
          nombre: "Juan",
          apellido: "Pérez",
          correo: "prst@aire.com",
          password: "prst123",
          rol: "prst",
          nombrePRST: "Telecom Solutions",
          cedula: "1234567890",
          matriculaProfesional: "MP-12345",
          direccion: "Calle 123 #45-67",
          barrio: "Centro",
          ciudad: "Barranquilla",
          celular: "3001234567",
          activo: true,
        },
        {
          id: "3",
          nombre: "María",
          apellido: "González",
          correo: "ejecutiva@aire.com",
          password: "ejecutiva123",
          rol: "ejecutiva",
          activo: true,
        },
        {
          id: "4",
          nombre: "Carlos",
          apellido: "Rodríguez",
          correo: "coordinador-admin@aire.com",
          password: "coordinador123",
          rol: "coordinador",
          tipoCoordinador: "administrativo",
          activo: true,
        },
        {
          id: "5",
          nombre: "Pedro",
          apellido: "Gómez",
          correo: "coordinador-op@aire.com",
          password: "coordinador123",
          rol: "coordinador",
          tipoCoordinador: "operativo",
          activo: true,
        },
        {
          id: "6",
          nombre: "Laura",
          apellido: "Díaz",
          correo: "coordinador-censo@aire.com",
          password: "coordinador123",
          rol: "coordinador",
          tipoCoordinador: "censo",
          activo: true,
        },
        {
          id: "7",
          nombre: "Ana",
          apellido: "Martínez",
          correo: "analista@aire.com",
          password: "analista123",
          rol: "analista",
          activo: true,
        },
        {
          id: "8",
          nombre: "Brigada",
          apellido: "Censo",
          correo: "brigada@aire.com",
          password: "brigada123",
          rol: "brigada",
          activo: true,
        },
      ]

      localStorage.setItem(this.KEYS.USERS, JSON.stringify(defaultUsers))
    }

    if (!localStorage.getItem(this.KEYS.PROJECTS)) {
      localStorage.setItem(this.KEYS.PROJECTS, JSON.stringify([]))
    }

    if (!localStorage.getItem(this.KEYS.NOTIFICATIONS)) {
      localStorage.setItem(this.KEYS.NOTIFICATIONS, JSON.stringify([]))
    }

    if (!localStorage.getItem(this.KEYS.CENSUS)) {
      localStorage.setItem(this.KEYS.CENSUS, JSON.stringify([]))
    }

    if (!localStorage.getItem(this.KEYS.COUNTER)) {
      localStorage.setItem(
        this.KEYS.COUNTER,
        JSON.stringify({
          projects: 1000,
          notifications: 1000,
          census: 1000,
          users: 10,
        }),
      )
    }

    // Imprimir usuarios para depuración
    console.log("Usuarios inicializados:", this.getUsers())
  },

  // Obtener todos los usuarios
  getUsers: function () {
    return JSON.parse(localStorage.getItem(this.KEYS.USERS) || "[]")
  },

  // Obtener usuario por ID
  getUserById: function (id) {
    const users = this.getUsers()
    return users.find((user) => user.id === id)
  },

  // Obtener usuario por correo
  getUserByEmail: function (email) {
    const users = this.getUsers()
    return users.find((user) => user.correo === email)
  },

  // Guardar usuario
  saveUser: function (user) {
    const users = this.getUsers()

    // Si no tiene ID, es un nuevo usuario
    if (!user.id) {
      const counter = this.getCounter()
      user.id = (++counter.users).toString()
      this.saveCounter(counter)
      users.push(user)
    } else {
      // Actualizar usuario existente
      const index = users.findIndex((u) => u.id === user.id)
      if (index !== -1) {
        users[index] = user
      } else {
        users.push(user)
      }
    }

    localStorage.setItem(this.KEYS.USERS, JSON.stringify(users))
    return user
  },

  // Eliminar usuario
  deleteUser: function (id) {
    const users = this.getUsers()
    const index = users.findIndex((user) => user.id === id)

    if (index !== -1) {
      users.splice(index, 1)
      localStorage.setItem(this.KEYS.USERS, JSON.stringify(users))
      return true
    }

    return false
  },

  // Autenticar usuario
  authenticateUser: function (email, password) {
    const users = this.getUsers()
    const user = users.find((u) => u.correo === email && u.password === password && u.activo)

    if (user) {
      this.setLoggedUser(user)
      return user
    }

    return null
  },

  // Establecer usuario logueado
  setLoggedUser: function (user) {
    localStorage.setItem(this.KEYS.LOGGED_USER, JSON.stringify(user))
  },

  // Obtener usuario logueado
  getLoggedUser: function () {
    return JSON.parse(localStorage.getItem(this.KEYS.LOGGED_USER))
  },

  // Cerrar sesión
  logout: function () {
    localStorage.removeItem(this.KEYS.LOGGED_USER)
  },

  // Obtener todos los proyectos
  getProjects: function () {
    return JSON.parse(localStorage.getItem(this.KEYS.PROJECTS) || "[]")
  },

  // Obtener proyecto por ID
  getProjectById: function (id) {
    const projects = this.getProjects()
    return projects.find((project) => project.id === id)
  },

  // Guardar proyecto
  // Dentro del objeto Storage, modificar el método saveProject:
  // Modificar el método saveProject para usar el nuevo ID
saveProject: function(project) {
  const projects = this.getProjects();
  
  try {
      // Si no tiene ID, es un nuevo proyecto
      if (!project.id) {
          // Generar el ID secuencial
          project.id = this.generateProjectId();
          
          // Incrementar contador
          const counter = this.getCounter();
          counter.projects = parseInt(project.id); // Actualizar al nuevo ID
          this.saveCounter(counter);
          
          // Establecer fecha de creación
          project.fechaCreacion = new Date().toISOString();
          project.estado = "Nuevo";
          
          projects.push(project);
          
          // Crear notificación
          this.createNotification({
              usuarioId: project.creadorId,
              tipo: "proyecto_creado",
              mensaje: `Has creado el proyecto "${project.nombre}" con ID ${project.id}.`,
              fechaCreacion: new Date().toISOString(),
              leido: false,
          });
      } else {
          // Actualizar proyecto existente
          const index = projects.findIndex((p) => p.id === project.id);
          if (index !== -1) {
              // Guardar la fecha de creación original
              const originalCreationDate = projects[index].fechaCreacion;
              project.fechaCreacion = originalCreationDate;
              
              // Actualizar proyecto
              project.fechaActualizacion = new Date().toISOString();
              projects[index] = project;
              
              // Crear notificación
              this.createNotification({
                  usuarioId: project.creadorId,
                  tipo: "proyecto_actualizado",
                  mensaje: `El proyecto "${project.nombre}" con ID ${project.id} ha sido actualizado.`,
                  fechaCreacion: new Date().toISOString(),
                  leido: false,
              });
          } else {
              // Esto no debería ocurrir, pero por si acaso
              projects.push(project);
          }
      }
      
      localStorage.setItem(this.KEYS.PROJECTS, JSON.stringify(projects));
      return project;
      
  } catch (error) {
      console.error("Error en saveProject:", error);
      throw error;
  }
},

// Añadir este nuevo método al objeto Storage:
generateProjectId: function() {
  const counter = this.getCounter();
  const nextId = counter.projects + 1;
  return nextId.toString(); // Retorna simplemente el siguiente número secuencial
},

  // Eliminar proyecto
  deleteProject: function (id) {
    const projects = this.getProjects()
    const index = projects.findIndex((project) => project.id === id)

    if (index !== -1) {
      projects.splice(index, 1)
      localStorage.setItem(this.KEYS.PROJECTS, JSON.stringify(projects))
      return true
    }

    return false
  },

  // Obtener todas las notificaciones
  getNotifications: function () {
    return JSON.parse(localStorage.getItem(this.KEYS.NOTIFICATIONS) || "[]")
  },

  // Obtener notificaciones por usuario
  getNotificationsByUser: function (userId) {
    const notifications = this.getNotifications()
    return notifications.filter((notification) => notification.usuarioId === userId)
  },

  // Crear notificación
  createNotification: function (notification) {
    const notifications = this.getNotifications()

    // Si no tiene ID, es una nueva notificación
    if (!notification.id) {
      const counter = this.getCounter()
      notification.id = (++counter.notifications).toString()
      this.saveCounter(counter)
    }

    notifications.push(notification)
    localStorage.setItem(this.KEYS.NOTIFICATIONS, JSON.stringify(notifications))
    return notification
  },

  // Marcar notificación como leída
  markNotificationAsRead: function (id) {
    const notifications = this.getNotifications()
    const index = notifications.findIndex((notification) => notification.id === id)

    if (index !== -1) {
      notifications[index].leido = true
      localStorage.setItem(this.KEYS.NOTIFICATIONS, JSON.stringify(notifications))
      return true
    }

    return false
  },

  // Marcar todas las notificaciones de un usuario como leídas
  markAllNotificationsAsRead: function (userId) {
    const notifications = this.getNotifications()
    let updated = false

    notifications.forEach((notification) => {
      if (notification.usuarioId === userId && !notification.leido) {
        notification.leido = true
        updated = true
      }
    })

    if (updated) {
      localStorage.setItem(this.KEYS.NOTIFICATIONS, JSON.stringify(notifications))
    }

    return updated
  },

  // Obtener contador
  getCounter: function () {
    return JSON.parse(
      localStorage.getItem(this.KEYS.COUNTER) || '{"projects":1000,"notifications":1000,"census":1000,"users":10}',
    )
  },

  // Guardar contador
  saveCounter: function (counter) {
    localStorage.setItem(this.KEYS.COUNTER, JSON.stringify(counter))
  },
}

